package com.example18.demo18;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo18ApplicationTests {

	@Test
	void contextLoads() {
	}

}
