package com.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {
	
    public static void main(String[] args)
    {
    
        ApplicationContext contex = new ClassPathXmlApplicationContext("applicationContext.xml");
		MemberShip m = (MemberShip) contex.getBean("membership");
		
		System.out.println("Member ID ::  "+m.getMembershipId());
		System.out.println("Membership Type ::  "+m.getMembershipType());
		System.out.println("Visits per year ::  "+m.getVisitsPerYear());
		System.out.println("Cusomer ID ::  "+m.getCustomer().getCustId());
		System.out.println("Cusomer Name ::  "+m.getCustomer().getCustName());
		System.out.println("Cusomer Email ::  "+m.getCustomer().getEmailId());
		System.out.println("Cusomer Contact ::  "+m.getCustomer().getContactNo());
		
	
    }

}

